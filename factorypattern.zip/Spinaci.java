package factorypattern;

import java.util.ArrayList;

public class Spinaci implements interfacefac {
	
	private ArrayList<String> ingredients=new ArrayList<String>();
	
	public Spinaci() {
        ingredients.add("Teig");
        ingredients.add("Tomatenso�e");
        ingredients.add("Kaese");
        ingredients.add("Spinat");
        ingredients.add("Tomaten");
	}
	
	@Override
	public void printIngredients() {
		for(String print:ingredients) {
			System.out.println(print);
		}
		
	}

}
