package factorypattern;

import java.util.ArrayList;

public class Tonno implements interfacefac {
	
	private ArrayList<String> ingredients=new ArrayList<String>();
	
	public Tonno() {
        ingredients.add("Teig");
        ingredients.add("Tomatenso�e");
        ingredients.add("Kaese");
        ingredients.add("Thunfisch");
        ingredients.add("Zwiebel");
	}
	
	@Override
	public void printIngredients() {
		for(String print:ingredients) {
			System.out.println(print);
		}
		
	}

}
