package factorypattern;

import java.util.ArrayList;

public class Margherita implements interfacefac {

private ArrayList<String> ingredients=new ArrayList<String>();
	
	public Margherita() {
        ingredients.add("Teig");
        ingredients.add("Tomatenso�e");
        ingredients.add("Kaese");
	}

	@Override
	public void printIngredients() {
		for(String print:ingredients) {
			System.out.println(print);		
	}
}	
}
