package factorypattern;

import java.util.Scanner;

public class Pizza {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		Scanner myObj = new Scanner(System.in);
		while(true) {
			String name = myObj.nextLine();
			
			if (name.equals("t")) {
				interfacefac tonno = new Tonno();
				tonno.printIngredients();
			}
		    
			if (name.equals("s")) {
				interfacefac spinaci = new Spinaci();
				spinaci.printIngredients();
			}
			
			if (name.equals("m")) {
				interfacefac margherita = new Margherita();
				margherita.printIngredients();
			}
			
		    System.out.println();
			}
		}
	
		
}
