package factorypattern;

public interface interfacefac {
	void printIngredients();
}
