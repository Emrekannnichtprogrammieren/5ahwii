package observerpattern;

import java.util.Scanner;

/*Aufgabenstellung : 

Es soll ein Programm gemacht werden, welche eine Heizung simuliert. 

Die Heizung ist das subject und ich und die Direktion sind Observer.

Wenn mich nicht nicht alles t�uscht interessiert mich erst die Temperatur �ber 25

Die Direktion jede �nderung

String Ausgaben reichen*/

public class HeizungMain {

	public static void main(String[] args) {
		
		Ich i = new Ich("Schoepf");
		Direktion dir = new Direktion("Direktor");
		Observe o = new Observe();
				
		o.add(i);
		o.add(dir);
		
	//dieser part also die ausgabe funktioniert auch nach mehrmaligem versuchen nicht 
		//ausser mit einem scanner aber da erscheinen trotzdem sehr viele fehler

	}
}

