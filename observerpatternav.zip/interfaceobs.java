package observerpattern;

public interface interfaceobs {
	//public void add(interfaceobs i);
	public void changeValue(int heat);
	
}
