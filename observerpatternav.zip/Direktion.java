package observerpattern;


public class Direktion implements interfaceobs {
	
	private String dir;
	
	public Direktion(String dir) {
		super();
		this.dir = dir;
	}

	public void notification(int heat) {
		System.out.println("Direktion :" + dir + heat);
		
	}

	@Override
	public void changeValue(int heat) {
		// TODO Auto-generated method stub
		
	}
}
