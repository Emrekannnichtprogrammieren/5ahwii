package observerpattern;

import java.util.ArrayList;
import java.util.List;

public class Observe  {
	private List<interfaceobs> observers = new ArrayList<>();
	@SuppressWarnings("unused")
	private int heat;
	
	public void add(interfaceobs i) {
		observers.add(i);
	}

	public void changeValue(int heat) {
		this.heat = heat;
		notification(heat);
		
	}
	
	public void notification(int heat) {
		for (interfaceobs i : observers) {
			i.notify();
		}
	}

}