package observerpattern;

public class Ich implements interfaceobs {

	private String name;
	
	public Ich(String name) {
		super();
		this.name = name;
	}
	
	public void notification (int heat) {
		if(heat > 24)	{
			System.out.println("Person :" + name + heat);
		}
	}

	@Override
	public void changeValue(int heat) {
		// TODO Auto-generated method stub
		
	}

}
